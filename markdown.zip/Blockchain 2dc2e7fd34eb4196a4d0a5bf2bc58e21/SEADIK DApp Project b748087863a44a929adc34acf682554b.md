# SEADIK DApp Project

[SEADIK DApp Project](https://www.notion.so/SEADIK-DApp-Project-6c4040cca1004c27bf02e7ccca10374b)
# Project Requirements

- Build the site using Elementor
- Get an A grade for page speed on GTMetrix (all pages)
- Focus more intently on content pages - make sure they're easily readable on all device sizes
# Cold Tasks

<aside>
💡 **Cold Tasks** are tasks with a priority other than **High** that have been overdue for more than 14 days. They'll show up here, and will be hidden from Inbox, Today, Tomorrow, and Next 7 Days. They'll still show up in Projects. For more, [check out the documentation](https://www.notion.so/Ultimate-Tasks-and-Projects-2fccba2d42e544a687194b6337272192).

</aside>

**[Inbox](Inbox%20e177f3203efd41d8bf59105c878978dc.md)   |   [Today](Today%203d26dc979b33417ea9530de75f6b5291.md)   |   [Tomorrow](Tomorrow%20d9366b721b284bfc8b55ffa401f41bed.md)   |   [Next 7 Days](Next%207%20Days%20e9e579f7ffdb417fb849d9015d3e7f51.md)**

[All Tasks](Cold%20Tasks%2018ab775bafcd4d248b6969cea8f446a4/All%20Tasks%207a03c6f6a4514bf3baddb70443270e4c.csv)

[Daily Tasks](Cold%20Tasks%2018ab775bafcd4d248b6969cea8f446a4/Daily%20Tasks%203175ad591ac7474c8678c66e7a5598ae.csv)

[Daily Tasks Archive](Daily%20Tasks%20Archive%204dea3fb1a2624f18832bbc9ac8b7d024.md) 

---

Ultimate Tasks for Notion by [Thomas Frank](https://thomasjfrank.com/)   |   [More Templates](https://thomasjfrank.com/templates/)   |   [Follow Me on Twitter](https://www.twitter.com/tomfrankly)
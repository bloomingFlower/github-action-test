# Change login URL

Cold: No
Created: 2022년 7월 9일 오전 12:01
Divider: 🛑🛑🛑🛑EVERYTHING BELOW HERE JUST RUNS THE TEMPLATE 🛑🛑🛑🛑
Done: Yes
Due: 2021년 9월 23일
Due Stamp (Parent): 1632369600000
Due Timestamp: 1632369600000
Edited: 2022년 7월 9일 오전 12:01
First Weekday Base Date: 1998년 9월 28일 오후 1:00
Kanban - State: To Do
Kanban - Tag: Security
Last Day Base Date: 1998년 9월 28일 오후 1:00
Last Weekday Base Date: 1998년 9월 28일 오후 1:00
Next Last Base Date: 1998년 9월 28일 오후 1:00
Priority: 🚨HIGH
Start: 2020년 10월 26일
State: 😀
Sub Seed: Yes
Sub Seed Name: Change login URL
Type: ⏳One-Time
UTC Offset: 0
⏱ Recurring Divider: 🛑🛑🛑 Helper functions for recurring tasks 🛑🛑🛑
✅ Sub-Task Divider: 🛑🛑🛑 Helper functions for sub-task sorting 🛑🛑🛑
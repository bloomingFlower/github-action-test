# Dependency

Stateful: Server and Client are tightly coupled, as in extremely interdependent on each other.
Stateless: Server and Client are more independent and hence, loosely coupled.
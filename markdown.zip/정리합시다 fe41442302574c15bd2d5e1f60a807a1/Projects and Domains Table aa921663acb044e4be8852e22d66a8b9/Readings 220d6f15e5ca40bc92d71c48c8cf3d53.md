# Readings

Archive: No
Date Created: 2022년 6월 19일 오전 6:16
Last review: 2022년 7월 9일
Next review: 2022년 7월 16일
Overdue: 🚩
Related to TKTM Task Table (Project): ../$10K%20Task%20Manager%20e1d56b02cc7148e697d8a5a9adc14819/Sign%20up%20for%20rock%20climbing%208ab70edacdfd4ce4ad34ccc97254622f.md, ../$10K%20Task%20Manager%20e1d56b02cc7148e697d8a5a9adc14819/%E1%84%8C%E1%85%A6%E1%84%86%E1%85%A9%E1%86%A8%20%E1%84%8B%E1%85%A5%E1%86%B9%E1%84%8B%E1%85%B3%E1%86%B7%20867ea46dfc044518af04fc2f00e90d52.md, ../$10K%20Task%20Manager%20e1d56b02cc7148e697d8a5a9adc14819/Programmer%E2%80%99s%20Brain%2038c4e74ccefe4a77bf6c6ded4c364f29.md
Type: Domain

<aside>
👉 Domains require an **ongoing** and **minimum** standard of excellence. Write below why this domain **is important to you?**

</aside>

```
 책은 타인이 겪은 수많은 시행착오와 경험을 담고 있다. 나도 가끔 느끼는 것이 이렇게 시간을 투자하고 고생해서 얻은 지식이고 경험인데 이것을 그냥 거져 공유하는게 과연 옳은 일인가 하는 고민이 들 때가 있다. 책 또한 그러한 내용을 담고 있고 대신에 책은 1차적으로 수익을 제공하고 2차적으로 명성을 부여할 수 있다.
 좋은 책은 보물과 같으며 저자와 동등하지만 못하지만 그 흐름을 어느정도 따라가고 흉내낼 수 있는 수준만 되어도 상당한 성공이라 생각한다. 인류 문명의 발전은 수많은 사람들의 시행 착오와 경험이 쌓이고 쌓여서 후대에 전해지고 그것이 단순히 구전이 아닌 문자라는 보전성이 강한 수단에 의해 쌓여 전해졌기 떄문이라 생각한다. 따라서 나라는 존재를 구석기시대부터 미래시대까지 끌어올리는 데 있어 책은 필수 요소이며 끝없이 함께 해야 할 중요한 수단이다!
```

[$10K Task Manager](Readings%20220d6f15e5ca40bc92d71c48c8cf3d53/$10K%20Task%20Manager%20dadc9366655441a0b33934be3330754a.csv)
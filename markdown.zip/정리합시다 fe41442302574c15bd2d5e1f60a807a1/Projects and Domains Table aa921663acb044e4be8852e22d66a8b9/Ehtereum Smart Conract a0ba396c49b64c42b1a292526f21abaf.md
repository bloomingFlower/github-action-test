# Ehtereum Smart Conract

Archive: No
Date Created: 2022년 6월 19일 오전 6:16
Last review: 2022년 1월 5일
Next review: 2022년 1월 12일
Overdue: 🚩
Type: Project

<aside>
👉 What defines **done?** How is this measurable and concrete?

</aside>

```

```

[$10K Task Manager](Ehtereum%20Smart%20Conract%20a0ba396c49b64c42b1a292526f21abaf/$10K%20Task%20Manager%2009cbf70787cb4ae78e2fd7dbdca4512a.csv)
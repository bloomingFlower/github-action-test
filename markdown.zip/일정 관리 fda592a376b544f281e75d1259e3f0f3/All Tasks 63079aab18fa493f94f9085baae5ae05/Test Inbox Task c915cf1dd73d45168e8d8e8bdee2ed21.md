# Test Inbox Task

Cold: Yes
Created: 2022년 7월 9일 오전 12:01
Created By: Nak Won
Divider: 🛑🛑🛑🛑EVERYTHING BELOW HERE JUST RUNS THE TEMPLATE 🛑🛑🛑🛑
Done: No
Due: 2022년 3월 18일
Due Stamp (Parent): 1647576000000
Due Timestamp: 1647576000000
Edited: 2022년 7월 9일 오전 12:01
First Weekday Base Date: 1998년 9월 28일 오후 1:00
Kanban - State: To Do
Last Day Base Date: 1998년 9월 28일 오후 1:00
Last Weekday Base Date: 1998년 9월 28일 오후 1:00
Late: ☠
Next Last Base Date: 1998년 9월 28일 오후 1:00
Priority: 🧀 Medium
State: 🔴
Sub Seed: Yes
Sub Seed Name: Test Inbox Task
Sub-Tasks: Test%20Sub-Task%20f4d7351bb48143c3afd5d2ca6ea11174.md, Test%20Sub-Task%202%20478de3ebd6684651b0c16ea06c00d135.md
Type: ⏳One-Time
UTC Offset: 0
⏱ Recurring Divider: 🛑🛑🛑 Helper functions for recurring tasks 🛑🛑🛑
✅ Sub-Task Divider: 🛑🛑🛑 Helper functions for sub-task sorting 🛑🛑🛑

[All Tasks](Test%20Inbox%20Task%20c915cf1dd73d45168e8d8e8bdee2ed21/All%20Tasks%20888512a8b3be46768c4a78265e9eb40b.csv)
# Userbase

Stateful: These are a thing of the past, and the dynamic user base is very less.
Stateless: These are the future because more and more industries are moving towards statelessness.
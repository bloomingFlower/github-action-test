# Requirement of Server

Stateful: The server is required to store and save status information and details of sessions.
Stateless: No server is needed for data storage.
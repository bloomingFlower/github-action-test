# Family

Archive: No
Date Created: 2022년 6월 19일 오전 6:16
Last review: 2022년 1월 5일
Next review: 2022년 1월 12일
Overdue: 🚩
Related to TKTM Task Table (Project): ../$10K%20Task%20Manager%20e1d56b02cc7148e697d8a5a9adc14819/Fund%20SEP%20IRA%20e732da9f06c54141b12cc6a3966d63eb.md, ../$10K%20Task%20Manager%20e1d56b02cc7148e697d8a5a9adc14819/Call%20accountant%20about%20501c3%20849d244ee99c44d2bab9b440b95a24fc.md, ../$10K%20Task%20Manager%20e1d56b02cc7148e697d8a5a9adc14819/Research%20new%20life%20insurance%20policy%202930ac2464b8430ebbc846a526cc8951.md, ../$10K%20Task%20Manager%20e1d56b02cc7148e697d8a5a9adc14819/Send%20my%20odometer%20reading%2061ccf746824447c386ebf51ee9bc8fc8.md, ../$10K%20Task%20Manager%20e1d56b02cc7148e697d8a5a9adc14819/Renew%20License%20ddc9884067a1435eadac84edad537130.md
Type: Domain

<aside>
👉 Domains require an **ongoing** and **minimum** standard of excellence. Write below why this domain **is important to you?**

</aside>

```

```

[$10K Task Manager](Family%20d58ac55fef764e55bd8acf9e8fb162a7/$10K%20Task%20Manager%20d690693efb2249bdb937377b4969af51.csv)
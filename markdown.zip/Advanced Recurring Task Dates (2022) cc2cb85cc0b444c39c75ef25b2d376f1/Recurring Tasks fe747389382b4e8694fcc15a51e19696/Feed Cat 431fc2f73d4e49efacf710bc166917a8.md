# Feed Cat

Assignee: Thomas Frank
Done: No
Due: 2022년 3월 24일
First Weekday Base Date: 1998년 9월 28일 오후 1:00
Last Day Base Date: 1998년 9월 28일 오후 1:00
Last Weekday Base Date: 1998년 9월 28일 오후 1:00
Next Due: 11월 21, 2022
Next Last Base Date: 1998년 9월 28일 오후 1:00
Recur Interval: 1
Recur Unit: Day(s)
Simplified Recur Unit: days
State: 🔴
Type: 🔄Recurring
UTC Offset: 0
# Test PerfMatters speed changes

Cold: Yes
Created: 2022년 7월 9일 오전 12:01
Divider: 🛑🛑🛑🛑EVERYTHING BELOW HERE JUST RUNS THE TEMPLATE 🛑🛑🛑🛑
Done: No
Due: 2022년 2월 10일
Due Stamp (Parent): 1644469200000
Due Timestamp: 1644469200000
Edited: 2022년 7월 9일 오전 12:01
First Weekday Base Date: 1998년 9월 28일 오후 1:00
Kanban - State: To Do
Kanban - Tag: Speed
Last Day Base Date: 1998년 9월 28일 오후 1:00
Last Weekday Base Date: 1998년 9월 28일 오후 1:00
Late: ☠
Next Last Base Date: 1998년 9월 28일 오후 1:00
Priority: 🧀 Medium
Start: 2020년 10월 25일
State: 🔴
Sub Seed: Yes
Sub Seed Name: Test PerfMatters speed changes
Type: ⏳One-Time
UTC Offset: 0
⏱ Recurring Divider: 🛑🛑🛑 Helper functions for recurring tasks 🛑🛑🛑
✅ Sub-Task Divider: 🛑🛑🛑 Helper functions for sub-task sorting 🛑🛑🛑
# TraderJoe

### LBPair.sol

d. LBPair: Liquidity Book Pair

v. bin: reserve, accTokenPerShare X, Y

v. tree: storage slot of tree

v. unclaimedFee

v. accureedDept

- f. mint: create LBPair
    -
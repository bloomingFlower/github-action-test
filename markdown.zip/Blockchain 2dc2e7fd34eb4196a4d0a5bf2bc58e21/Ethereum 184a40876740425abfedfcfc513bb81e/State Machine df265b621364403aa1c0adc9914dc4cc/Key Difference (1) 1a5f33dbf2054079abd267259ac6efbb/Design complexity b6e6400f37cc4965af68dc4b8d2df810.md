# Design complexity

Stateful: This makes the design heavy and complex since data needs to be stored.
Stateless: Server design is simplified in this case.
# Response mechanism

Stateful: Stateful expects a response and if no answer is received, the request is resent.
Stateless: In stateless, the client sends a request to a server, which the server responds to based on the state of the request.
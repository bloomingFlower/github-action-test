# Programming

Stateful: It is difficult to code as one of the salient features here is data storage.
Stateless: It is much easier to code.
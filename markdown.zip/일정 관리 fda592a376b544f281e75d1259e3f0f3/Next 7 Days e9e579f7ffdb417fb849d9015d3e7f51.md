# Next 7 Days

<aside>
💡 Next 7 Days functions exactly like Today, except it shows all tasks due on or before 7 days from now.

</aside>

**[Inbox](Inbox%20e177f3203efd41d8bf59105c878978dc.md)   |   [Today](Today%203d26dc979b33417ea9530de75f6b5291.md)   |   [Tomorrow](Tomorrow%20d9366b721b284bfc8b55ffa401f41bed.md)**

[All Tasks](Next%207%20Days%20e9e579f7ffdb417fb849d9015d3e7f51/All%20Tasks%20b544cecfe75e4e80bf33a6121ec5a0e6.csv)

[Daily Tasks](Next%207%20Days%20e9e579f7ffdb417fb849d9015d3e7f51/Daily%20Tasks%20b9ba122838574a35b33c50f1e8b33215.csv)

[Daily Tasks Archive](Daily%20Tasks%20Archive%204dea3fb1a2624f18832bbc9ac8b7d024.md) 

---

Ultimate Tasks for Notion by [Thomas Frank](https://thomasjfrank.com/)   |   [More Templates](https://thomasjfrank.com/templates/)   |   [Follow Me on Twitter](https://www.twitter.com/tomfrankly)
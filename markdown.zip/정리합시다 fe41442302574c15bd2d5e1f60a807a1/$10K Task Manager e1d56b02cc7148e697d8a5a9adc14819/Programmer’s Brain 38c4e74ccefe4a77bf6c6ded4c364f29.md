# Programmer’s Brain

Context: 🏡 Home, 🔁 Recurring
Date Modified: 2022년 7월 8일 오후 10:59
Date created: 2022년 6월 19일 오전 6:16
Do Date: 2022년 7월 9일
Done: No
Energy Level: 🔋 High Energy
Project/Domain: ../Projects%20and%20Domains%20Table%20aa921663acb044e4be8852e22d66a8b9/Readings%20220d6f15e5ca40bc92d71c48c8cf3d53.md
Value: 10k

개발 커뮤니터에서 지속적으로 추천 받은 책으로 출간된지 얼마된 것은 아니지만 읽어볼 가치가 상당히 있다고 생각함.
# Requests

Stateful: Requests are always dependent on the server-side.
Stateless: Requests are self-contained and not dependent on the server side.
# Servers Specifications

Stateful: The same server must be utilized to process every request.
Stateless: Different servers can be used to process different information at a time.
# Jop Position

Archive: No
Date Created: 2022년 6월 19일 오전 6:16
Last review: 2022년 1월 5일
Next review: 2022년 1월 12일
Overdue: 🚩
Related to TKTM Task Table (Project): ../$10K%20Task%20Manager%20e1d56b02cc7148e697d8a5a9adc14819/Look%20up%20Stoics%20+%20pleasure%206d5bd17955a84a208201da4eb416788a.md
Type: Domain

<aside>
👉 Domains require an **ongoing** and **minimum** standard of excellence. Write below why this domain **is important to you?**

</aside>

```

```

[$10K Task Manager](Jop%20Position%20ececb4289fc7434c87bd56687857ca8e/$10K%20Task%20Manager%207e70fc9101cf4ef59fb2f3f28e2c1caf.csv)
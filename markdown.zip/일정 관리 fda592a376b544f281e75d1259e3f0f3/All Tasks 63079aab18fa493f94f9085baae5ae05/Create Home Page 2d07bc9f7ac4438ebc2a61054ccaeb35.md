# Create Home Page

Cold: No
Created: 2022년 7월 9일 오전 12:01
Created By: Nak Won
Divider: 🛑🛑🛑🛑EVERYTHING BELOW HERE JUST RUNS THE TEMPLATE 🛑🛑🛑🛑
Done: No
Due: 2022년 6월 18일
Due Stamp (Parent): 1655524800000
Due Timestamp: 1655524800000
Edited: 2022년 7월 9일 오전 12:01
First Weekday Base Date: 1998년 9월 28일 오후 1:00
Kanban - State: Doing
Kanban - Tag: Design
Last Day Base Date: 1998년 9월 28일 오후 1:00
Last Weekday Base Date: 1998년 9월 28일 오후 1:00
Late: ☠
Next Last Base Date: 1998년 9월 28일 오후 1:00
Priority: 🚨HIGH
Project: ../Projects%20a4c53eed60a84e5f985bc3540088c2bb/Website%20Redesign%20%5BDEMO%20PROJECT%5D%20e808854d73ae41f3b6aef952816385dd.md
Start: 2020년 10월 23일
State: 🔴
Sub Seed: Yes
Sub Seed Name: Create Home Page
Sub-Tasks: Design%20header%20a6fa0a20e8484712839151577bb6c9c4.md, Test%20full-width%20splash%20image%20702e25f7a5ed44669414590331cac844.md, Design%20footer%20520f7afcace349a08d8b5475f7632321.md
Type: ⏳One-Time
UTC Offset: 0
⏱ Recurring Divider: 🛑🛑🛑 Helper functions for recurring tasks 🛑🛑🛑
✅ Sub-Task Divider: 🛑🛑🛑 Helper functions for sub-task sorting 🛑🛑🛑

[All Tasks](Create%20Home%20Page%202d07bc9f7ac4438ebc2a61054ccaeb35/All%20Tasks%202823665469a54d8eb779fd50e184191c.csv)
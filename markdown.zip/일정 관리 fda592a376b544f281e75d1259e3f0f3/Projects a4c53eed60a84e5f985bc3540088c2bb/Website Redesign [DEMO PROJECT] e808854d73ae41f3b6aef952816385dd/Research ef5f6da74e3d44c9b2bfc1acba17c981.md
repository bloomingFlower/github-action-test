# Research

Tools and resources to use on this project:

[Hello - The Best Elementor & WordPress Theme | Elementor.com](https://elementor.com/hello-theme/)

[Elementor: #1 Free WordPress Website Builder | Elementor.com](https://elementor.com/)

[Caching Plugin for WordPress - Speed up your website with WP Rocket](https://wp-rocket.me/)

[Perfmatters - The #1 Web Performance Plugin for WordPress](https://perfmatters.io/)
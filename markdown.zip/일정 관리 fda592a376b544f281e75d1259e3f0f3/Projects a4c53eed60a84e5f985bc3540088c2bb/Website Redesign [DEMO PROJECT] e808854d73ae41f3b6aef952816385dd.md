# Website Redesign [DEMO PROJECT]

Archive: No
Created: 2022년 7월 9일 오전 12:01
Edited: 2022년 7월 9일 오전 12:01
Meta: 5 Tasks, 4 Overdue
Overdue Tasks: 4
Progress: ◻◻◻◼◼◼◼◼◼◼ 29%
Project Tasks: 5
Status: Doing
Tasks: ../All%20Tasks%2063079aab18fa493f94f9085baae5ae05/Test%20PerfMatters%20speed%20changes%200577152d87284af195be365f0e40d7ef.md, ../All%20Tasks%2063079aab18fa493f94f9085baae5ae05/Change%20login%20URL%200ec010063e2c484aa8ebfe09d2d3d535.md, ../All%20Tasks%2063079aab18fa493f94f9085baae5ae05/Create%20Home%20Page%202d07bc9f7ac4438ebc2a61054ccaeb35.md, ../All%20Tasks%2063079aab18fa493f94f9085baae5ae05/Dateless%20task%205833397c7833401f82d9d3bc70c4386a.md, ../All%20Tasks%2063079aab18fa493f94f9085baae5ae05/Write%20About%20page%20copy%20837237e2acb44182a888ee7c3fb21974.md, ../All%20Tasks%2063079aab18fa493f94f9085baae5ae05/Take%20new%20picture%20for%20homepage%20background%20d00a0bc9cae34ac19c0ce4e310930c47.md, ../All%20Tasks%2063079aab18fa493f94f9085baae5ae05/Install%202FA%20plugin%20d5dd17542be54a6bb601ece05dca5436.md
Tasks Done: 0.2857142857142857

<aside>
💡 **Project Overview:** Redesign [thomasjfrank.com](http://thomasjfrank.com) to be faster, more modern, and to have a greater focus on content and SEO-friendliness. *Feel free to delete this project after you've looked it over a bit to learn how the projects system works.*

</aside>

- Project Info
    
    [Project Requirements](Website%20Redesign%20%5BDEMO%20PROJECT%5D%20e808854d73ae41f3b6aef952816385dd/Project%20Requirements%20f60398d472b94f5db2b77374f6d13995.md)
    
    [Research](Website%20Redesign%20%5BDEMO%20PROJECT%5D%20e808854d73ae41f3b6aef952816385dd/Research%20ef5f6da74e3d44c9b2bfc1acba17c981.md)
    

[All Tasks](Website%20Redesign%20%5BDEMO%20PROJECT%5D%20e808854d73ae41f3b6aef952816385dd/All%20Tasks%20a14a471d352a43b19eb18222de24ef1b.csv)
# Task Due Tomorrow

Cold: Yes
Created: 2022년 7월 9일 오전 12:01
Divider: 🛑🛑🛑🛑EVERYTHING BELOW HERE JUST RUNS THE TEMPLATE 🛑🛑🛑🛑
Done: No
Due: 2022년 2월 10일
Due Stamp (Parent): 1644469200000
Due Timestamp: 1644469200000
Edited: 2022년 7월 9일 오전 12:01
First Weekday Base Date: 1998년 9월 28일 오후 1:00
Kanban - State: To Do
Last Day Base Date: 1998년 9월 28일 오후 1:00
Last Weekday Base Date: 1998년 9월 28일 오후 1:00
Late: ☠
Next Due: 11월 28, 2022
Next Last Base Date: 1998년 9월 28일 오후 1:00
Priority: 🧀 Medium
Recur Interval: 3
Simplified Recur Unit: days
State: 🔴
Sub Seed: Yes
Sub Seed Name: Task Due Tomorrow
Type: 🔄Recurring
UTC Offset: 0
⏱ Recurring Divider: 🛑🛑🛑 Helper functions for recurring tasks 🛑🛑🛑
✅ Sub-Task Divider: 🛑🛑🛑 Helper functions for sub-task sorting 🛑🛑🛑
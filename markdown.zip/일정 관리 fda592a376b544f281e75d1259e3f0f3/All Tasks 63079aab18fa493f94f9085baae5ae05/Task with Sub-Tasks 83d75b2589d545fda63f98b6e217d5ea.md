# Task with Sub-Tasks

Cold: Yes
Created: 2022년 7월 9일 오전 12:01
Created By: Nak Won
Divider: 🛑🛑🛑🛑EVERYTHING BELOW HERE JUST RUNS THE TEMPLATE 🛑🛑🛑🛑
Done: No
Due: 2021년 12월 8일
Due Stamp (Parent): 1638939600000
Due Timestamp: 1638939600000
Edited: 2022년 7월 9일 오전 12:01
First Weekday Base Date: 1998년 9월 28일 오후 1:00
Kanban - State: To Do
Last Day Base Date: 1998년 9월 28일 오후 1:00
Last Weekday Base Date: 1998년 9월 28일 오후 1:00
Late: ☠
Next Last Base Date: 1998년 9월 28일 오후 1:00
Priority: 🧀 Medium
State: 🔴
Sub Seed: Yes
Sub Seed Name: Task with Sub-Tasks
Sub-Tasks: Sub-Task%201%2013f68afcbe8f4709acdcbf2328efdd7f.md, Sub-Task%202%202374d2fcdfe3463e9e3030acc64e8b83.md
Type: ⏳One-Time
UTC Offset: 0
⏱ Recurring Divider: 🛑🛑🛑 Helper functions for recurring tasks 🛑🛑🛑
✅ Sub-Task Divider: 🛑🛑🛑 Helper functions for sub-task sorting 🛑🛑🛑

[All Tasks](Task%20with%20Sub-Tasks%2083d75b2589d545fda63f98b6e217d5ea/All%20Tasks%20b67b65b5260b437586b4d58c0d043fb0.csv)
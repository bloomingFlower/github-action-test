# Definition

Stateful: Stateful Protocols require the server to save the state of a process.
Stateless: Stateless Protocols do not need the server to save the state of a process.
# Priority View

<aside>
💡 The Priority View lets you sort and view tasks by their priority level. No matter where they're created, all tasks are given Medium priority by default.

</aside>

**[Inbox](Inbox%20e177f3203efd41d8bf59105c878978dc.md)   |   [Today](Today%203d26dc979b33417ea9530de75f6b5291.md)   |   [Tomorrow](Tomorrow%20d9366b721b284bfc8b55ffa401f41bed.md)   |   [Next 7 Days](Next%207%20Days%20e9e579f7ffdb417fb849d9015d3e7f51.md)**

[All Tasks](Priority%20View%2032486ac73cc247d799974ad321aeda3f/All%20Tasks%20272f7af125af4106b84de8df51e9ced2.csv)

[Daily Tasks](Priority%20View%2032486ac73cc247d799974ad321aeda3f/Daily%20Tasks%2099b2193549394651bb4eb85122ac6ccf.csv)

[Daily Tasks Archive](Daily%20Tasks%20Archive%204dea3fb1a2624f18832bbc9ac8b7d024.md) 

---

Ultimate Tasks for Notion by [Thomas Frank](https://thomasjfrank.com/)   |   [More Templates](https://thomasjfrank.com/templates/)   |   [Follow Me on Twitter](https://www.twitter.com/tomfrankly)
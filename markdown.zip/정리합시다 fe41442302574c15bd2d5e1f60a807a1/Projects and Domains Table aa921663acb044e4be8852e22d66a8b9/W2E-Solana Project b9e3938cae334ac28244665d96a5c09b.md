# W2E-Solana Project

Archive: No
Date Created: 2022년 6월 19일 오전 6:16
Last review: 2022년 1월 5일
Next review: 2022년 1월 12일
Overdue: 🚩
Type: Project

<aside>
👉 Domains require an **ongoing** and **minimum** standard of excellence. Write below why this domain **is important to you?**

</aside>

```

```

[$10K Task Manager](W2E-Solana%20Project%20b9e3938cae334ac28244665d96a5c09b/$10K%20Task%20Manager%20fa82dd50ccac4745855f15827301f2ce.csv)
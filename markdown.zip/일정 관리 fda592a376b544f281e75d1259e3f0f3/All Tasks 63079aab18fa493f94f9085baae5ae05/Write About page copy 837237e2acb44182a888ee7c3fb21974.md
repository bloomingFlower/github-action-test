# Write About page copy

Cold: Yes
Created: 2022년 7월 9일 오전 12:01
Created By: Nak Won
Divider: 🛑🛑🛑🛑EVERYTHING BELOW HERE JUST RUNS THE TEMPLATE 🛑🛑🛑🛑
Done: No
Due: 2021년 10월 14일
Due Stamp (Parent): 1634184000000
Due Timestamp: 1634184000000
Edited: 2022년 7월 9일 오전 12:01
First Weekday Base Date: 1998년 9월 28일 오후 1:00
Kanban - State: To Do
Kanban - Tag: Copy
Last Day Base Date: 1998년 9월 28일 오후 1:00
Last Weekday Base Date: 1998년 9월 28일 오후 1:00
Late: ☠
Next Last Base Date: 1998년 9월 28일 오후 1:00
Priority: 🧀 Medium
Project: ../Projects%20a4c53eed60a84e5f985bc3540088c2bb/Website%20Redesign%20%5BDEMO%20PROJECT%5D%20e808854d73ae41f3b6aef952816385dd.md
Start: 2020년 10월 28일
State: 🔴
Sub Seed: Yes
Sub Seed Name: Write About page copy
Sub-Tasks: Overdue%20Sub-Task%20Example%20be8fdefd4abe4dce89a41ab6619c7499.md
Type: ⏳One-Time
UTC Offset: 0
⏱ Recurring Divider: 🛑🛑🛑 Helper functions for recurring tasks 🛑🛑🛑
✅ Sub-Task Divider: 🛑🛑🛑 Helper functions for sub-task sorting 🛑🛑🛑

[All Tasks](Write%20About%20page%20copy%20837237e2acb44182a888ee7c3fb21974/All%20Tasks%20d9148654e8dd437ebbb2bc07361f1532.csv)
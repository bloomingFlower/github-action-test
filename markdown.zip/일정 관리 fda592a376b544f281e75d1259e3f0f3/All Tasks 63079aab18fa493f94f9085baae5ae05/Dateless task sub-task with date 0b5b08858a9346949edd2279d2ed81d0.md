# Dateless task sub-task with date

Cold: Yes
Created: 2022년 7월 9일 오전 12:01
Divider: 🛑🛑🛑🛑EVERYTHING BELOW HERE JUST RUNS THE TEMPLATE 🛑🛑🛑🛑
Done: No
Due: 2022년 3월 15일
Due Stamp (Parent): 1647316800000
Due Timestamp: 1647316800000
Edited: 2022년 7월 9일 오전 12:01
First Weekday Base Date: 1998년 9월 28일 오후 1:00
Kanban - State: To Do
Last Day Base Date: 1998년 9월 28일 오후 1:00
Last Weekday Base Date: 1998년 9월 28일 오후 1:00
Late: ☠
Next Last Base Date: 1998년 9월 28일 오후 1:00
Priority: 🧀 Medium
State: 🔴
Sub Seed: Yes
Sub Seed Name: Dateless task sub-task with date
Type: ⏳One-Time
UTC Offset: 0
⏱ Recurring Divider: 🛑🛑🛑 Helper functions for recurring tasks 🛑🛑🛑
✅ Sub-Task Divider: 🛑🛑🛑 Helper functions for sub-task sorting 🛑🛑🛑
# Install New Graphics Driver

Assignee: Thomas Frank
Done: No
Due: 2020년 10월 25일
First Weekday Base Date: 1998년 9월 28일 오후 1:00
Last Day Base Date: 1998년 9월 28일 오후 1:00
Last Weekday Base Date: 1998년 9월 28일 오후 1:00
Next Last Base Date: 1998년 9월 28일 오후 1:00
State: 🔴
Type: ⏳One-Time
UTC Offset: 0
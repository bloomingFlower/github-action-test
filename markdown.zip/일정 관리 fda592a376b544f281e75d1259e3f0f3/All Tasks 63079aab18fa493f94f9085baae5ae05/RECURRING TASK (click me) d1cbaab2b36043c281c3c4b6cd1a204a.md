# RECURRING TASK (click me)

Cold: No
Created: 2022년 7월 9일 오전 12:01
Divider: 🛑🛑🛑🛑EVERYTHING BELOW HERE JUST RUNS THE TEMPLATE 🛑🛑🛑🛑
Done: No
Due: 2022년 6월 19일
Due Stamp (Parent): 1655611200000
Due Timestamp: 1655611200000
Edited: 2022년 7월 9일 오전 12:01
First Weekday Base Date: 1998년 9월 28일 오후 1:00
Kanban - State: To Do
Last Day Base Date: 1998년 9월 28일 오후 1:00
Last Weekday Base Date: 1998년 9월 28일 오후 1:00
Late: ☠
Next Due: 11월 4, 2022
Next Last Base Date: 1998년 9월 28일 오후 1:00
Priority: 🚨HIGH
Recur Interval: 6
Recur Unit: Day(s)
Simplified Recur Unit: days
State: 🔴
Sub Seed: Yes
Sub Seed Name: RECURRING TASK (click me)
Type: 🔄Recurring
UTC Offset: 0
⏱ Recurring Divider: 🛑🛑🛑 Helper functions for recurring tasks 🛑🛑🛑
✅ Sub-Task Divider: 🛑🛑🛑 Helper functions for sub-task sorting 🛑🛑🛑

Heyo! 

Ultimate Tasks comes with the ability to track **recurring tasks** without needing to rely on an external app or API integration.

However, you can *also* use platforms like [Make.com](http://Make.com) and [Automate.io](http://Automate.io) to **completely automate** your recurring tasks without any coding.

Check out this page in the wiki for all the details: [How to Create Recurring Tasks](https://www.notion.so/How-to-Create-Recurring-Tasks-b6b776a266b546d8a46e255a79cca09e)
# Transaction Handling

Stateful: Transaction handling is relatively slow in the stateful protocol.
Stateless: This is relatively faster in the stateless protocol.
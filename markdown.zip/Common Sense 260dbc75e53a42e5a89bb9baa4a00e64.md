# Common Sense

문제 접근 방식에 대한 전반적인 분석을 다시 할 필요가 있음!!

mapping annotation 해결 방식 참고!

[javamana.com/2021/01/20210105181540418a.html](http://javamana.com/2021/01/20210105181540418a.html)

주말사용설명서!!

부족한 부분 학습을 최우선으로!

주기적인 독서(매일 30분)

설득의 심리학

피아노 연습(매일 30분)

Simply Piano
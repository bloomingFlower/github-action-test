# Implementation

Stateful: They are logically heavy to implement.
Stateless: They are easy to implement.
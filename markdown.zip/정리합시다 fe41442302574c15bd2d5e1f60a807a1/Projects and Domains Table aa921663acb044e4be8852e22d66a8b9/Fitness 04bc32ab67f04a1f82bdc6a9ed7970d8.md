# Fitness

Archive: No
Date Created: 2022년 6월 19일 오전 6:16
Last review: 2022년 1월 5일
Next review: 2022년 1월 12일
Overdue: 🚩
Related to TKTM Task Table (Project): ../$10K%20Task%20Manager%20e1d56b02cc7148e697d8a5a9adc14819/%E1%84%80%E1%85%A1%E1%84%89%E1%85%B3%E1%86%B7%20%E1%84%83%E1%85%B3%E1%86%BC%207babc60091f541f68b1eeae6d35d8f74.md
Type: Domain

<aside>
👉 Domains require an **ongoing** and **minimum** standard of excellence. Write below why this domain **is important to you?**

</aside>

```
아침에 운동하는 것을 원칙으로 한다. (저녁에 하면 게을러져서 임의로 스킵할 수 있음. 아침에 일찍 일어나서 해당 운동을 하겠다고 정의했으면 아침에 일어나도 할게 없어서 운동을 하게 됨.)
무엇가를 하기 위해서는 에너지가 필요하다. 체력을 관리하고 불특정의 사고가 일어날 때 그에 대해 충분히 대응하려면 신체적 능력을 어느정도 갖추어야 한다.
몸을 활성화하면 두뇌에도 좋다. 몸을 밸런스있게 보여주고 장시간 특정 자세로 있어도 보완이 된다.
```

[Fitness](Fitness%2004bc32ab67f04a1f82bdc6a9ed7970d8/Fitness%20bceb670fb0954f2f95d4cde0bb7ba610.csv)

[$10K Task Manager](Fitness%2004bc32ab67f04a1f82bdc6a9ed7970d8/$10K%20Task%20Manager%205695169969e848bbb20fc36ab166ed90.csv)
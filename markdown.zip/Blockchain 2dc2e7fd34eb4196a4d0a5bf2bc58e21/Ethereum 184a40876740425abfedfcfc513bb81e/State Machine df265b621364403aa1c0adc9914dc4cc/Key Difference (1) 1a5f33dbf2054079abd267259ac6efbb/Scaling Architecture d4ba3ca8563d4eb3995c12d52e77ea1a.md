# Scaling Architecture

Stateful: Scaling architecture is difficult and complex.
Stateless: It is relatively easier to scale architecture.
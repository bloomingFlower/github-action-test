# Working State

Stateful: They react only by the current state of a transaction or request.
Stateless: They act independently by taking the previous or next request into consideration.